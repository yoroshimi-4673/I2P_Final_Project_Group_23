================================================================
 COZY INTERIORS & TOWN LIFE
 16x16 Top-Down Asset Pack v1.0  -  FREE / name your own price
================================================================

Thank you for downloading! This pack is the INSIDE of the world:
interior tiles for 12 building styles, 375 furniture pieces, lights,
wall decor, daily-life character animations (sit, sleep, eat,
drink, read, write, cook, sweep, hammer, shopkeeper, wave, talk),
10 new indoor NPCs, indoor pets, 140 item icons, house-decorating UI
and cozy effects.

Total: 4,408 sprites & animation frames in 2,023 PNG files.
(Every animation frame is counted once; ready-cut strips that repeat
frames of a sheet are NOT counted again. Left-facing rows are
mirrored copies of the right-facing rows - they are included so
everything works out of the box. Recolors are listed below.)

PART OF A FREE SERIES - same 16x16 grid, same style, same palette:
 1. Cozy Village & Farm
 2. Fantasy Dungeon & Adventure
 3. Wild Lands: Biomes & Adventure Towns
 4. Cozy Interiors & Town Life (this pack) - the insides of the
    buildings from packs 1-3.

----------------------------------------------------------------
TECH SPECS
----------------------------------------------------------------
- Tiles 16x16. Characters 16x32 (tool actions 32x32). Furniture on
  the 16 grid (16x16, 32x16, 16x32, 32x32, 48x32, 32x48, 48x48, 64x32).
- Palette: the same 55 colors as Wild Lands (Cozy Village 46 +
  Dungeon 6 + Wild Lands 3). NO new colors were added. Files in
  /Palette (.png .gpl .hex). All sprites: palette colors only,
  hard alpha (0 or 255).
- 1px dark outline (#2b1e2f) on objects/characters, none on floor
  tiles and rugs. Light from the top-left. 3/4 top-down view.
- Import: Filter = Point / Nearest, Compression = None.
  Unity: Pixels Per Unit = 16. Godot 4: Texture filter = Nearest.

----------------------------------------------------------------
FOLDERS
----------------------------------------------------------------
01_Interior_Tiles  Floors: 48 style floors (4 per style: base, _b variant,
                   alternative material, worn) + 21 generic floors (parquet,
                   herringbone, painted planks, checker tiles, glazed
                   tiles, wall-to-wall carpets).
                   Rugs: 6 auto-tile rugs (16-tile corner sets) + 24 ready-made
                   rugs (48x32, round 32x32, 64x48, runner 16x48). Door mats.
02_Walls_Doors     12 interior styles: adobe, castle, cellar, harbor, igloo, jungle, log_cabin, palace, ship_cabin, swamp, village_plaster, village_wood.
                   Per style: 2-tile-tall wall faces (single/left/mid/right),
                   short walls (left/mid/right), 47-blob wall tops, door
                   opening animation (4f, + closed/open singles), window
                   day/night, stairs down/up.
                   Wallpapers: 8 wallpaper faces (stripes, floral, damask,
                   dots, wainscot) with short walls.
                   Extras: trapdoors, ladders, curtain windows (4 colors,
                   day/night), double windows, stained glass (2f).
                   _GUIDE_room_layout.png and _GUIDE_47blob_wall_tops.png.
03_Furniture       375 files (34 of them animated strips): Bedroom,
                   Living_Room, Kitchen, Bathroom, Tavern_Inn, Shops (9 shop
                   types), Workshops (blacksmith, alchemy, library, wizard,
                   tailor, carpenter), Temple, Royal (thrones, pillars,
                   banquet, canopy bed), Cellar_Storage, Ship_Cabin,
                   Witch_Hut, Tribal_Igloo, Tabletop (food & dishes to put
                   on tables).
04_Lights_Decor    19 animated lights (candles, candelabras, chandeliers,
                   lanterns, paper lanterns, sconces, ship lantern, torches,
                   brazier) + 50 wall decor files (paintings, shelves, clocks
                   incl. pendulum & cuckoo anims, banners, tapestries,
                   antlers, maps, mirrors, curtains, garland...).
05_Characters_     Players/ (pack 1 player + player_girl): ALL 12 actions.
   Actions         Indoor_NPCs/ (10): sit, sleep, eat, drink, talk, wave + job
                   actions (maid: sweep + shopkeeper, chef: cook, librarian:
                   read + write ...).
                   Compatible_Pack1-3/: sit (4 dirs) + sleep for 50 characters
                   of packs 1-3 (10 villagers, 6 pack 2 heroes, 4 pack 3
                   heroes, 30 pack 3 NPCs).
06_NPCs_Pets       Indoor_NPCs: maid, butler, librarian, chef, bartender,
                   tailor, baker, bard, healer, child in pajamas (walk/idle
                   sheets + 32x32 portraits).
                   Pets: cats (4 colors) & dogs (4 colors) with walk + idle +
                   sleep, parrots (3 colors, perch + fly), hamsters (2
                   colors, idle/run/sleep), hamster wheel, mouse, goldfish
                   bowl. Pet_Accessories: beds, bowls, scratching post,
                   hamster cage, bird perch.
07_Items           140 icons: furniture catalog icons, food & drinks, dishes,
                   books & scrolls, household tools, decorations, keys.
                   _ALL_ITEMS_16x16_sheet.png has every icon.
08_UI              Decorating (catalog window, 8 category tabs x 2 states,
                   rotate/move/delete/confirm/cancel buttons x 3 states,
                   placement highlight ok/blocked 2f, 32x32 footprints,
                   grid tile), Shop (window, price tags, qty buttons, coin),
                   Cooking (window, progress 8f, pot timer 6f, quality
                   stars), Rest_Sleep (rest window, day banner, day-to-night
                   8f, sleep fade 4 steps, save icon 4f), Prompts (E/F/Q/R,
                   SPACE, gamepad A/B/X/Y, mouse - 2f), Emotes (10).
09_Effects         14 FX strips: steam, smoke, fireplace sparks, cooking
                   bubbles (2 colors), hearts, Zzz, sweep dust, clean
                   sparkle, water splash, bath bubbles, music notes, page
                   flip, crumbs + Light_Circles (dithered light pools, warm
                   & cool, 32/48/64 px, 2f flicker).
Example_Scenes     13 scenes (1x + 3x + 6-frame GIF): bedroom, kitchen,
                   tavern, harbor shop, blacksmith, library, alchemy lab,
                   throne room, temple, ship cabin, witch hut, palace hall
                   and a cut-away village street with an open house.
                   The street uses Cozy Village grass, houses and trees.
Previews           GIFs, rug seam tests and content overview sheets.
Palette            Palette files.

----------------------------------------------------------------
LAYOUTS
----------------------------------------------------------------
ROOM (see 02_Walls_Doors/_GUIDE_room_layout.png)
  Row 0 = wall tops, rows 1-2 = 16x32 wall FACE columns (left end,
  mid, right end; _single for a 1-wide wall), side + bottom walls =
  wall tops only. A door column replaces one face column.
  Furniture that stands against the wall overlaps the lower part of
  the face (3/4 view). Windows/paintings/shelves are overlays.
WALL TOPS (*_wall_tops_47blob.png): 8 cols x 6 rows, 47 tiles, same
  mask convention as Fantasy Dungeon: bits N=1 NE=2 E=4 SE=8 S=16
  SW=32 W=64 NW=128 (bit set = neighbour is wall; diagonals only
  count when both touching sides are wall). Treat the wall FACE
  cells as "not wall". Godot 4: "Match Corners and Sides".
RUG AUTO-TILES (rug_<color>_autotile_16tiles.png, 64x64): the 16-tile
  corner layout of Cozy Village (bits TL TR BL BR, 1 = rug). Rugs
  are transparent outside, so put them on a layer above the floor.
  Tiled: Wang "Corner" set. Godot 4: Terrain "Match Corners".
CHARACTER ACTION SHEETS (<name>_<action>_<w>x<h>_sheet.png)
  rows: down, up, right, left | cols: frames (2 or 4).
  sit (16x32, 2f): place the frame on the chair tile so the chair
    is the lower 16 px. For an up-facing chair, draw
    chair_*_up_back_layer.png AFTER the character.
  eat / drink / read / write (16x32, 4f): sitting poses (same
    placement as sit).
  sleep (16x16, 4f, one direction): head + shoulders on the pillow.
    Use it with a bed_*_occupied.png (draw it 2 px below the bed top).
  cook / sweep / hammer (32x32, 4f): character centred, tool may
    reach outside the 16 px column.
  shopkeeper_idle (16x32, 4f, rows down/right/left): stand behind
    a counter so the counter covers the legs.
  wave / talk (16x32, 4f).
  Ready-cut strips: <name>_strips/<name>_<action>_<dir>_<N>f.png.
NPC SHEETS (*_walk_idle_sheet.png): 16x32, 6 cols x 4 rows (rows
  down, up, right, left | cols walk 0-3, idle 4-5) - same as packs 1-3.
PET SHEETS (cat_/dog_<color>_sheet.png): 16x16, 4 cols x 6 rows:
  rows walk down, up, right, left, idle, sleep.
PEWS (facing up): draw pew_*_facing_up, then the sitters (sit "up"
  frame, 19 px above the pew top), then pew_*_up_back_layer.

----------------------------------------------------------------
RECOLORS (honest list)
----------------------------------------------------------------
- Beds: walnut + birch frames are recolors of the oak frame (made state).
- Wardrobes, dressers, nightstands: walnut / birch / painted are wood recolors of oak.
- Chairs, stools, tables, benches: walnut / birch / painted are recolors of oak.
- Armchairs + sofas: 4 fabric colors (red / green / blue / yellow) of the same design.
- Fireplaces: 5 materials of the same fireplace (stone, brick, marble, adobe, cobble).
- Cauldrons: 3 brew colors (green / purple / blue) of the same animation.
- Wall tops: the 12 style sets use the same 47 shapes in different
  colors. Wall faces, floors, doors and windows are drawn per style.
- Rugs: one rug pattern in 6 colorways (auto-tile + fixed rugs).
- Wallpapers: 5 patterns, 8 colorways.
- Pets: cat/dog walk rows use the pack 1 animal bodies recolored per
  coat; parrots 3 colors, hamsters 2 colors.
- Lights: silver candelabra, iron + wood chandelier, blue wall
  lantern, yellow paper lantern and iron sconce are recolors.
- Items: 4 book colors and the silver/gold/iron key are recolors.
- Character actions: the same animations are applied to many
  characters (each character is drawn with its own colors/hair/hat).

----------------------------------------------------------------
ANIMATION SPEED TIPS
----------------------------------------------------------------
Sit / sleep breathing 2-3 fps | eat, drink, read, write 5-6 fps |
cook, sweep, hammer 8-10 fps | fire & candles 8-10 fps | clocks 2 fps |
doors 10 fps | pets idle 4 fps, sleep 2-3 fps | effects 10-12 fps

----------------------------------------------------------------
ENGINE TIPS
----------------------------------------------------------------
Unity: Sprite Editor > Slice > Grid By Cell Size. Tile Palette for
       floors; 2D Tilemap Extras "Rule Tile" for the rugs (corner) and
       wall tops (47-blob). Put floors, rugs, walls and furniture on
       separate tilemaps/sorting layers; sort furniture & characters
       by Y (Transparency Sort Axis 0,1,0).
Godot 4: TileSet atlas 16x16, Terrains as above. Y-Sort Enabled on
       the furniture/character layer. AnimatedSprite2D > SpriteFrames >
       "Add frames from sprite sheet".
Tiled: tileset 16x16, Wang sets as above, animated tiles via the
       Tile Animation Editor; furniture as an object layer.
GameMaker: "Import Strip Image" (frame count = *_4f in the file
       name). Tile sets 16x16; auto-tile 16 for rugs, 47 for walls.

----------------------------------------------------------------
LICENSE: see LICENSE.txt  |  Made with AI assistance -
programmatically generated pixel art, reviewed and curated.
================================================================
