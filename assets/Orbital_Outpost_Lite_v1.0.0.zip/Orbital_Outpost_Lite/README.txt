Orbital Outpost Lite v1.0.0
24 clean painted sci-fi props for space colonies, labs and top-down shooters: consoles, containers, machines and hazards.

This is the free Lite edition: a small, polished starter set. Larger paid packs may follow.

WHAT'S INCLUDED
- Consoles (6): Command Console, Radar Terminal, Lever Panel, Holo Table, Wall Monitor, Keypad Lock
- Containers (6): Supply Crate, Cryo Pod, Fuel Canister, Cargo Container, Medical Locker, Ammo Box
- Machines (6): Generator, Oxygen Tank, Air Filter, 3D Printer, Tool Bench, Drone Dock
- Hazards (6): Radiation Barrel, Toxic Barrel, Laser Post, Warning Beacon, Wiring Box, Broken Panel

Every item is a transparent PNG on a square 288 px canvas (items centered), in three sizes:
Icons_Native (288 px, the original resolution), Icons_128 and Icons_64.

NOT INCLUDED
No animation, no sprite atlas or sheet, no source files. Items are static images.

AI DISCLOSURE
These images were created with AI image generation and processed by hand (background removal, cutting, resizing).

LICENSE
See LICENSE.txt. Free for personal and commercial projects. If you like it, a donation is welcome but never required.
