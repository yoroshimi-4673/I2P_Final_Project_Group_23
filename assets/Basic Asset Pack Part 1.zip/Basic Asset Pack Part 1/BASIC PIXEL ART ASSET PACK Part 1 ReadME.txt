==================================================
BASIC PIXEL ART ASSET PACK
Created by: Brakkosaur
Version: 1.0 (Part 1)
==================================================

Thank you for downloading the Basic Pixel Art Asset Pack! 
This pack was designed to give indie developers a complete, cohesive foundation for top-down 2D games. Whether you are building an RPG, a farming sim, or a dungeon crawler, these assets are ready to be dropped into your engine.

--------------------------------------------------
📁 FOLDER STRUCTURE
--------------------------------------------------
1_Furniture/   - Beds, tables, chairs, wardrobes, and bookshelves.
2_Items/       - Weapons, armor, potions, food, and crafting materials.
3_Terrain/     - 47-tile Blob autotiles for grass, dirt, sand, and stone + water tiles connected to each & 3 types of mountainsides.
4_UI/          - Health bars, heart containers, and keyboard prompts.

--------------------------------------------------
🛠️ HOW TO USE THE TERRAIN (AUTOTILES)
--------------------------------------------------
The terrain files are set up in a standard 47-tile "Blob" format (compatible with Godot 4, RPG Maker, and most modern engines). 
* Note: You do not need to manually place every edge tile. Just set up the terrain rules in your engine, and it will automatically pull the correct corners, diagonals, and transitions from the sheet.
* If your engine requires an 8x6 grid (like Godot), ensure your tile size is set correctly in the import settings. 

--------------------------------------------------
⚖️ LICENSE & TERMS OF USE
--------------------------------------------------
This asset pack is 100% FREE to use.
* You CAN use these assets in personal and commercial projects (including games you sell).
* You CAN edit, recolor, and modify the sprites to fit your game.
* You CANNOT redistribute, resell, or repackage these assets as your own asset pack. 

You do NOT need to credit me, but it is always appreciated! If you do, you can credit me as: itch.io/Brakkosaur 

--------------------------------------------------
📬 FEEDBACK & SUPPORT
--------------------------------------------------
This is a growing asset pack. If you find any bugs, have suggestions for Part 2, or just want to show me the game you are making, feel free to reach out!

Also don't forget to check out my free Character Customizer on Itch.io & Patreon!

Twitter/Bluesky: Brakkosaur
Patreon: Patreon.com/Brakkosaur
Itch.io: itch.io/Brakkosaur 

Happy Game Dev!