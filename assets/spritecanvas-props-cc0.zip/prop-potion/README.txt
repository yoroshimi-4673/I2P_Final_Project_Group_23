Potion - free sprite sheets (CC0)

A round blue potion bottle with bubbling liquid.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-potion-bubble.png: 26 frames, 95x124 cells, 10 fps, loop, pivot 47,118

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
