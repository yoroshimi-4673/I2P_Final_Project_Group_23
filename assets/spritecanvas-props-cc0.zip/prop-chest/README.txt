Treasure chest - free sprite sheets (CC0)

A wooden treasure chest that unlocks and opens to show gold and gems (plays once; the last frame is the open chest).

Sheets (8 frames per row, read left to right, top to bottom):
- prop-chest-open.png: 28 frames, 186x211 cells, 16 fps, plays once, pivot 83,204

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
