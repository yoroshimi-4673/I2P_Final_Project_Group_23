Torch - free sprite sheets (CC0)

A wooden torch with a flickering flame.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-torch-burn.png: 26 frames, 39x173 cells, 12 fps, loop, pivot 19,167

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
