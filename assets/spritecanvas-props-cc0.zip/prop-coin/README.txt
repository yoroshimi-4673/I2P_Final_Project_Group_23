Gold coin - free sprite sheets (CC0)

A gold star coin spinning in place, for pickups.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-coin-spin.png: 32 frames, 107x108 cells, 16 fps, loop, pivot 54,101

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
