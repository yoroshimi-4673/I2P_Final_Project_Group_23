Magic crystal - free sprite sheets (CC0)

A cyan crystal that bobs up and down and glows.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-crystal-float.png: 26 frames, 62x153 cells, 12 fps, loop, pivot 31,145

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
