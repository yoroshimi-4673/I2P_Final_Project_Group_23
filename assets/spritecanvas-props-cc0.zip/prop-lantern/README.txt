Lantern - free sprite sheets (CC0)

A standing iron lantern swaying gently with a candle flame.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-lantern-sway.png: 29 frames, 112x158 cells, 14 fps, loop, pivot 55,151

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
