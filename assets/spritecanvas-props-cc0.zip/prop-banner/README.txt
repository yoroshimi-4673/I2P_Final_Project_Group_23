Banner - free sprite sheets (CC0)

A blue banner with a gold sword emblem waving on a pole.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-banner-wave.png: 35 frames, 97x189 cells, 14 fps, loop, pivot 54,182

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
