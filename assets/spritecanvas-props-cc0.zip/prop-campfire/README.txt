Campfire - free sprite sheets (CC0)

A campfire in a stone ring with dancing flames.

Sheets (8 frames per row, read left to right, top to bottom):
- prop-campfire-burn.png: 26 frames, 137x147 cells, 12 fps, loop, pivot 68,140

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
