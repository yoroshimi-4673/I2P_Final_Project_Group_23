SpriteCanvas animated fantasy props (CC0)

Eight animated props for 2D games. Each one is a PNG sprite sheet on a transparent background with a
JSON Hash atlas (Phaser load.atlas, PixiJS Assets). Each folder has a README with frame count, cell
size, fps and the bottom pivot.

- chest: open (plays once)
- coin: spin, torch: burn, campfire: burn, potion: bubble, crystal: float, lantern: sway, banner: wave (all loop)

License: CC0 1.0 (see LICENSE.txt in each folder). Credit is welcome but not required.
The art was generated with AI in the SpriteCanvas workflow: https://spritecanvas.com/free-sprite-sheets/
