# MattIAco - Cozy Decor Props Pack Vol.2 - Free Demo

10 of the 40 items, free: sofa, armchair, desk, mirror_wall, wardrobe, bedside_table, nightstand, books_shelf_small, fireplace, carpet_large (32 px + 64 px each, same group folders as the full pack).

Full pack (40 items) - 2.99 EUR: https://mattiaco.itch.io/mattia-cozy-decor-2

## Licence

Commercial use allowed in your own games and projects, free or paid. No redistribution or resale of the raw assets. Credit "MattIAco Studio" appreciated, not required.

## AI disclosure

AI-assisted pixel art generated with prompts and reviewed for style consistency. Every asset passed human QC (40/40, 2026-10-24).

MattIAco Studio - https://mattiaco.itch.io
